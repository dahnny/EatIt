package com.danielogbuti.akilihealth;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.danielogbuti.akilihealth.models.User;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.viewpager.widget.ViewPager;

public class SurveyActivity extends AppCompatActivity {
    private ViewPager viewPager;
    private FragmentAdapter adapter;
    private TextView userNameText;
    private User user;
    private Button nextButton;
    private ImageView previous;
    private ImageView next;
    private static int currentPage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_survey);

        viewPager = findViewById(R.id.pager);
        nextButton = (Button)findViewById(R.id.nextButton);
        userNameText = (TextView)findViewById(R.id.usernameText);
         Toolbar toolbar = (Toolbar)findViewById(R.id.toolbar);
        if (toolbar != null){
            setSupportActionBar(toolbar);
            getSupportActionBar().show();
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        }

        user = Common.currentUser;
        userNameText.setText("Hi "+user.getName()+"!\n"+" We have a few questions." );

        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SurveyActivity.this,MapActivity.class);
                startActivity(intent);
            }
        });

        adapter = new FragmentAdapter(getSupportFragmentManager());

        viewPager.setAdapter(adapter);
        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int i, float v, int i1) {

            }

            @Override
            public void onPageSelected(int i) {

                if(i == 2){
                    nextButton.setVisibility(View.VISIBLE);
                }else{
                    nextButton.setVisibility(View.INVISIBLE);
                }
            }

            @Override
            public void onPageScrollStateChanged(int i) {

            }
        });


    }

}
