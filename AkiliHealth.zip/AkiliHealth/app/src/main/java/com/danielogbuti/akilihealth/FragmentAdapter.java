package com.danielogbuti.akilihealth;

import com.danielogbuti.akilihealth.fragments.Question_Age;
import com.danielogbuti.akilihealth.fragments.Question_Temperament;
import com.danielogbuti.akilihealth.fragments.Question_work;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;

public class FragmentAdapter extends FragmentStatePagerAdapter {
    private int int_items = 3;

    public FragmentAdapter(FragmentManager fm) {
        super(fm);
    }

    @Override
    public Fragment getItem(int i) {
        switch (i){
            case 0:
                return new Question_Age();
            case 1:
                return new Question_Temperament();
            case 2:
                return new Question_work();

            default:
                return null;
        }

    }

    @Override
    public int getCount() {
        return int_items;
    }
}
