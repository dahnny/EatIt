package com.danielogbuti.akilihealth;

import com.danielogbuti.akilihealth.models.User;

public class Common {
    public static User currentUser;
    public static int number;
}
