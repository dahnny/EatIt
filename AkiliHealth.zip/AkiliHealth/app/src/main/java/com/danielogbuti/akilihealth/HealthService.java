package com.danielogbuti.akilihealth;

import android.Manifest;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.app.JobIntentService;

public class HealthService extends JobIntentService implements GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener,LocationListener {

    private final static int INTERVAL = 1000 * 60 ;
    public static final String PREF_IS_ALARM_ON = "isAlarmOn";
    private final String TAG = "Fragment";
    private Double presentLatitude;
    private Double presentLongitude;
    private Long selectedLatitude;
    private Long selectedLongitude;
    private GoogleApiClient googleApiClient;
    private LocationRequest mLocationRequest;
    private final String PREF_LATITUDE = "latitude";
    private final String PREF_LONGITUDE = "longitude";
    private long startTimer;
    private long endTimer;
    private long screenOnTime;
    AsyncTask<?,?,?> runningTask;
    Double mainDouble;



    @Override
    protected void onHandleWork(@NonNull Intent intent) {
        Log.i(TAG,"I made it here");
        startLocating();
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        selectedLatitude = preferences.getLong(PREF_LATITUDE,0);
        selectedLongitude = preferences.getLong(PREF_LONGITUDE,0);



        //double dist =  distance(selectedLatitude,selectedLongitude,presentLatitude,presentLongitude);
        //Log.i(TAG,dist + " ");
        Location location = new Location("Point A");
        location.setLatitude(selectedLatitude);
        location.setLongitude(selectedLatitude);

        Location locationB =  new Location("Point B");
        locationB.setLatitude(presentLatitude);
        locationB.setLongitude(presentLongitude);

        float dist = location.distanceTo(locationB);

        if (dist/1000 <= 1){
            if (intent.getAction().equals(Intent.ACTION_SCREEN_ON)){
                startTimer = System.currentTimeMillis();
            }else if (intent.getAction().equals(Intent.ACTION_SCREEN_OFF)){
                endTimer = System.currentTimeMillis();
                screenOnTime = endTimer - startTimer;
            }

            if (screenOnTime > 1000){
                screenOnTime += screenOnTime;
            }
            Log.i(TAG,screenOnTime+"");
        }


    }
    private long distance(long lat1, long lon1, double lat2, double lon2) {
        double theta = lon1 - lon2;
        long dist = (long) (Math.sin(deg2rad(lat1))
                        * Math.sin(deg2rad(lat2))
                        + Math.cos(deg2rad(lat1))
                        * Math.cos(deg2rad(lat2))
                        * Math.cos(deg2rad(theta)));
        dist = (long) Math.acos(dist);
        dist = (long) rad2deg(dist);
        dist = (long) (dist * 60 * 1.1515);
        return (dist);
    }

    private double deg2rad(double deg) {
        return (deg * Math.PI / 180.0);
    }

    private double rad2deg(double rad) {
        return (rad * 180.0 / Math.PI);
    }

    private void startLocating() {
        Log.i(TAG,"Started locating");
        if (googleApiClient == null) {
            googleApiClient = new GoogleApiClient.Builder(this)
                    .addConnectionCallbacks(this)
                    .addOnConnectionFailedListener(this)
                    .addApi(LocationServices.API)
                    .build();
        }else {

        }
        if (!googleApiClient.isConnected()){
            googleApiClient.connect();
        }
    }


    public static boolean isServiceAlarmOn(Context context){
        Intent intent = new Intent(context, HealthReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(context,0,intent,PendingIntent.FLAG_NO_CREATE);
        return pendingIntent !=null;

    }

    public static void setServiceAlarm(Context context,boolean isOn){

        Intent intent = new Intent(context,HealthReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(context,0,intent,0);

        AlarmManager alarmManager =(AlarmManager)context.getSystemService(Context.ALARM_SERVICE);

        if (isOn){
            alarmManager.setRepeating(AlarmManager.RTC,System.currentTimeMillis(),INTERVAL,pendingIntent);

        }else {
            alarmManager.cancel(pendingIntent);
            pendingIntent.cancel();
        }

        PreferenceManager.getDefaultSharedPreferences(context)
                .edit()
                .putBoolean(PREF_IS_ALARM_ON,isOn)
                .apply();
    }



    @Override
    public void onConnected(@Nullable Bundle bundle) {
        mLocationRequest = LocationRequest.create();
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        mLocationRequest.setInterval(1000*60*5);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED &&
                    ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
                            != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                return;
            }
        }
        LocationServices.FusedLocationApi.requestLocationUpdates(googleApiClient, mLocationRequest, this);
    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }

    @Override
    public void onLocationChanged(Location location) {
        Log.i(TAG,"Found current");
        if (location == null){
            Toast.makeText(this, "Cant get current location", Toast.LENGTH_SHORT).show();
        }else {
            presentLatitude = location.getLatitude();
            presentLongitude = location.getLongitude();
            googleApiClient.disconnect();
        }

    }


}
