package com.danielogbuti.akilihealth.fragments;


import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.danielogbuti.akilihealth.R;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;

/**
 * A simple {@link Fragment} subclass.
 */
public class Question_Age extends Fragment {

    ImageView next;
    ImageView previous;
    private FragmentActivity mContext;

    public Question_Age() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.fragment_question__age, container, false);
        return rootView;
    }

}
