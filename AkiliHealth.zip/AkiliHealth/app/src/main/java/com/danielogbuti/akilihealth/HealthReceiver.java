package com.danielogbuti.akilihealth;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.util.Log;

public class HealthReceiver extends BroadcastReceiver {
    private final String TAG = "Fragment";
    public static final String PREF_IS_ALARM_ON = "isAlarmOn";

    @Override
    public void onReceive(Context context, Intent intent) {
        Log.i(TAG,"Received intent"+intent.getAction());

        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
        boolean isOn =preferences.getBoolean(PREF_IS_ALARM_ON,false);
        intent.setClass(context,HealthService.class);
        if (HealthService.isServiceAlarmOn(context)){
            HealthService.enqueueWork(context,HealthService.class,1,intent);
        }else {
            HealthService.setServiceAlarm(context,isOn);
        }
    }
}
